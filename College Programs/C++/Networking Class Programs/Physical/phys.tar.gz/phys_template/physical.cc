// This is just a template for you to use in your coding

#include "physical.h"

extern int blabby;

// Start the thread

int  physical::init (char *name, protocol *higher, protocol *lower, 
 char *address, int port, int client)
{
  int hServerSocket;  /* handle to socket */
  struct hostent* pHostInfo;   /* holds info about a machine */
  struct sockaddr_in Address; /* Internet socket address stuct */
  int nAddressSize=sizeof(struct sockaddr_in);
  long nHostAddress;
  int err;

  cout << "This is the physical init routine for " << name << endl;
  strcpy(prot_name , name);
  prot_higher = higher;
  prot_lower = lower;
  // You should put code to set up the socket here
        /* make a socket */
  
 
}

// Push the data to the next lower layer
int physical::push (unsigned char *buf, int len, char *addr, message *mb)
{
  int rval, total; 

  if(blabby & 0x1) {
    cout << "This is the physical push routine" << endl;
    print_chars(prot_name, buf, len);
  }


}




