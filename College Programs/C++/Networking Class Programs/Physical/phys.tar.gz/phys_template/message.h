// Message.h

#ifndef _MESSAGE_H
#define _MESSAGE_H

#include <ctype.h>
#include <iostream.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdio.h>


void print_chars(char *head, unsigned char *buff, int length);

class message {
private:

public:

};

#endif _MESSAGE_H
