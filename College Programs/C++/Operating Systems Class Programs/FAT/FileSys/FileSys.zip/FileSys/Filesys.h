#ifndef _FILESYS
#define _FILESYS
#define READONLY 0x01
#define HIDDEN 0x02
#define SYSTEM 0x04
#define VOLUME 0x08
#define DIRECT 0x10
#define ARCHIVE 0x20

#pragma pack(push, 1)


struct fatdate {
	WORD day:5;
	WORD month:4;
	WORD year:7;
};

struct fattime {
	WORD sec:5;
	WORD min:6;
	WORD hour:5;
};

struct directory_entry {
	BYTE Name[8];
	BYTE Extension[3];
	BYTE Attributes;
	BYTE REserved[10];
	WORD Time;
	WORD Date;
	WORD startCluster;
	DWORD fileSize;

};

struct bootsector {
	BYTE jump[3];
	BYTE SysName[8];
	WORD BytesPerSector;
	BYTE SectorsPerCluster;
	WORD ReservedSectors;
	BYTE FATcount;
	WORD MaxRootEntries;
	WORD TotalSectors1;
	BYTE MediaDescriptor;
	WORD SectorsPerFAT;
	WORD SectorsPerTrack;
	WORD HeadCount;
	DWORD HiddenSectors;
	DWORD TotalSectors2;
	BYTE DriveNumber;
	BYTE Reserved1;
	BYTE ExtBootSignature;
	DWORD VolumeSerial;
	BYTE VolumeLabel[11];
	BYTE Reserved2[8];
};


pragma pack(pop)



class FileSystem {

public:
WORD GetCluster(WORD fatEntry);
void SetCluster(WORD cluster, WORD FAT12ClusEntryVal);
int fdListDir();
int fdChangeDir(char *directory);
int fdEraseFile(char *name);
int fdDelDir(char *directory);
int fdCopyFile(char *source, char *destination);
int ReadSector(int index, BYTE *buffer, int count);
int WriteSector(int index, BYTE *buffer, int count);
void Print_Directory_Entry(directory_entry dirent);

private:
	HANDLE diskHandle;
	long curDirectory;
	bootsector bs;
	BYTE* FAT1;
	BYTE* FAT2;
};


#endif 