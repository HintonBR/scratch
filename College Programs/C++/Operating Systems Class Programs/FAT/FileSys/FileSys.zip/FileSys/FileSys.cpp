#include "stdlib.h"
#include "Filesys.h"

int main() {

	diskHandle = CreateFile("\\\\.\\A:", GENERIC_READ+GENERIC_WRITE, FILE_SHARE_READ+FILE_SHARE_WRITE, NULL, OPEN_EXISTING, 0, NULL);


}


int FileSystem::ReadSector(int index, BYTE *buffer, int count) {
	
	int err;
	OVERLAPPED overlap;
	DWORD dwRead;
	memset(&overlap, 0, sizeof(OVERLAPPED));

	overlap.Offset = index * 512;

	if (ReadFile(diskHandle, uffer, 512 * count, &dwRead, &overlap)) err=1;
	else  {
		LPVOID lpMsgBuf;
		FormatMessage(FORMAT_MESSAGE_ALLOCATE_BUFFER |
			FORMAT_MESSAGE_FROM_SYSTEM |
			FORMAT_MESSAGE_IGNORE_INSERTS, 
			NULL,
			GetLastError(),
			MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), //Default Language
			(LPTSTR) &lpMsgBuf,
			0,
			NULL);
		printf("Error: %s\n", lpMsgBuf);
		err=0;

	}
	return err;
}

int FileSystem::WriteSector(int index, BYTE *buffer, int count) {
	int err;
	OVERLAPPED overlap;
	DWORD dwWrite;
	memset(&overlap, 0, sizeof(OVERLAPPED));
	overlap.Offset = index * 512;

	if (WriteFile(diskHandle, buffer, 512 * count, &dwWrite, &overlap)) err = 1;
	else {
		LPVOID lpMsgBuf;
		FormatMessage(FORMAT_MESSAGE_ALLOCATE_BUFFER |
			FORMAT_MESSAGE_FROM_SYSTEM |
			FORMAT_MESSAGE_IGNORE_INSERTS, 
			NULL,
			GetLastError(),
			MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), //Default Language
			(LPTSTR) &lpMsgBuf,
			0,
			NULL);
		printf("Error: %s\n", lpMsgBuf);
		err=0;
	}
	return err;
}

void FileSystem::Print_Directory_Entry(directory_entry dirent) {
	unsigned char i;
	fatdate d;
	fattime t;
	for (i=0; i<8; i++) printf("%c", dirent.Name[i]);
	printf("\t");
	for (i=0; i<3; i++) printf("%c", dirent.Extension[i]);
	if (dirent.Attributes & 0x01) printf("\tR"); else printf("\t-");
	if (dirent.Attributes & 0x02) printf("H"); else printf("-");
	if (dirent.Attributes & 0x04) printf("S"); else printf("-");
	if (dirent.Attributes & 0x08) printf("V"); else printf("-");
	if (dirent.Attributes & 0x10) printf("D"); else printf("-");
	if (dirent.Attributes & 0x20) printf("A\t"); else printf("-");
	memcpy(&t, &dirent.Time, sizeof(WORD));
	printf("%02d:%02d:%02d\t", t.hour, t.min, t.sec*2);
	memcpy(&d, &dirent.Date, sizeof(WORD));
	printf("%02d/%02d/%04d\t", d.month, d.day, d.year+1980);
	printf("%d\t", dirent.startCluster);
	printf("%d", dirent.fileSize);
	printf("\n");
}

int FileSystem::fdListDir(){

}
int FileSystem::fdChangeDir(char *directory){

}
int FileSystem::fdEraseFile(char *name){

}
int FileSystem::fdDelDir(char *directory){

}
int FileSystem::fdCopyFile(char *source, char *destination){

}

WORD FileSystem::GetCluster(WORD fatEntry){
	WORD sector;
	int FatIndex = ((fatEntry * 3) /2 );
	if (fatEntry & 0x0001)	{
		sector = *((WORD *) &FAT[FatIndex]);
		sector = sector >> 4 ;
	}
	else {
			sector = *((WORD *) &FAT[FatIndex]);
			sector = sector & 0xffff;
	}
	return sector;
}
void FileSystem::SetCluster(WORD cluster, WORD FAT12ClusEntryVal){
	WORD ThisFATEntOffset = (cluster * 3) /2;
	if (cluster & 0x0001) {
		FAT12ClusEntryVal = FAT12ClusEntryVal << 4;
		*((WORD *) &FAT[ThisFATEntOffset]) = (*((WORD *) &FAT[ThisFATEntOffset])) & 0xF000;
	}
	else {
		FAT12ClusEntryVal = FAT12ClusEntryVal & 0x0FFF;
		*((WORD *) &FAT[ThisFATEntOffset]) = (*((WORD *) &FAT[ThisFATEntOffset])) & 0x000F;
	}
}